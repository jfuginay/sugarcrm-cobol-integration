<?php
/**
 * Menu configuration for Payment Bridge Module
 */

if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $module_menu;

$module_menu = array();

if (ACLController::checkAccess('PaymentBridge', 'view', true)) {
    $module_menu[] = array(
        'index.php?module=PaymentBridge&action=index',
        'LBL_MODULE_NAME',
        'PaymentBridge'
    );
}

if (ACLController::checkAccess('PaymentBridge', 'edit', true)) {
    $module_menu[] = array(
        'index.php?module=PaymentBridge&action=ValidateCard',
        'LBL_VALIDATE_CARD',
        'ValidateCard'
    );
    
    $module_menu[] = array(
        'index.php?module=PaymentBridge&action=InterestCalculator',
        'LBL_INTEREST_CALCULATOR',
        'InterestCalculator'
    );
    
    $module_menu[] = array(
        'index.php?module=PaymentBridge&action=GenerateStatement',
        'LBL_GENERATE_STATEMENT',
        'GenerateStatement'
    );
    
    $module_menu[] = array(
        'index.php?module=PaymentBridge&action=CreditLimitDashboard',
        'LBL_CREDIT_LIMIT_DASHBOARD',
        'CreditLimitDashboard'
    );
    
    $module_menu[] = array(
        'index.php?module=PaymentBridge&action=PaymentPlanManager',
        'LBL_PAYMENT_PLAN_MANAGER',
        'PaymentPlanManager'
    );
    
    $module_menu[] = array(
        'index.php?module=PaymentBridge&action=SystemHealthMonitor',
        'LBL_SYSTEM_HEALTH_MONITOR',
        'SystemHealthMonitor'
    );
}
?>