<?php
/**
 * COBOL Payment Bridge Module for SuiteCRM
 * 
 * This module enables integration with legacy COBOL payment systems,
 * providing modern payment capabilities while preserving existing infrastructure.
 * 
 * @package PaymentBridge
 * @version 1.0.0
 * @author Enterprise Integration Team
 * @license AGPLv3
 */

$manifest = array(
    'acceptable_sugar_versions' => array(
        'regex_matches' => array(
            '7\..*\..*',
            '8\..*\..*'
        ),
    ),
    'acceptable_sugar_flavors' => array(
        'CE',
        'PRO',
        'ENT'
    ),
    'readme' => 'README.txt',
    'key' => 'PB',
    'author' => 'Enterprise Integration Team',
    'description' => 'Enterprise COBOL Payment System Integration - Enables real-time payment processing, credit validation, interest calculations, and statement generation through legacy COBOL systems',
    'icon' => 'images/PaymentBridge.png',
    'is_uninstallable' => true,
    'name' => 'COBOL Payment Bridge',
    'published_date' => '2025-01-21',
    'type' => 'module',
    'version' => '1.0.0',
    'remove_tables' => 'prompt',
);

$installdefs = array(
    'id' => 'PaymentBridge',
    'beans' => array(
        array(
            'module' => 'PaymentBridge',
            'class' => 'PaymentBridge',
            'path' => 'modules/PaymentBridge/PaymentBridge.php',
            'tab' => true,
        ),
    ),
    'layoutdefs' => array(),
    'relationships' => array(),
    'copy' => array(
        array(
            'from' => '<basepath>/modules/PaymentBridge',
            'to' => 'custom/modules/PaymentBridge',
        ),
        array(
            'from' => '<basepath>/images/PaymentBridge.png',
            'to' => 'custom/themes/default/images/PaymentBridge.png',
        ),
    ),
    'language' => array(
        array(
            'from' => '<basepath>/language/application/en_us.lang.php',
            'to_module' => 'application',
            'language' => 'en_us',
        ),
    ),
    'menu' => array(
        array(
            'from' => '<basepath>/menu/PaymentBridge.php',
            'to_module' => 'PaymentBridge',
        ),
    ),
    'post_install' => array(
        '<basepath>/scripts/post_install.php',
    ),
    'post_uninstall' => array(
        '<basepath>/scripts/post_uninstall.php',
    ),
    'pre_install' => array(
        '<basepath>/scripts/pre_install.php',
    ),
    'pre_uninstall' => array(
        '<basepath>/scripts/pre_uninstall.php',
    ),
);
?>