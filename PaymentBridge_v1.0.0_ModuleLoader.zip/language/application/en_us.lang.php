<?php
/**
 * Application Language File for Payment Bridge Module
 */

$app_list_strings['moduleList']['PaymentBridge'] = 'Payment Bridge';
$app_list_strings['moduleListSingular']['PaymentBridge'] = 'Payment Bridge';

// Add Payment Bridge to the main menu
$app_list_strings['moduleList']['PaymentBridge'] = 'Payment Bridge';

// Status options
$app_list_strings['payment_status_list'] = array(
    'pending' => 'Pending',
    'approved' => 'Approved',
    'declined' => 'Declined',
    'processing' => 'Processing',
    'completed' => 'Completed',
    'failed' => 'Failed',
    'refunded' => 'Refunded',
);

// Card types
$app_list_strings['card_type_list'] = array(
    'visa' => 'Visa',
    'mastercard' => 'MasterCard',
    'amex' => 'American Express',
    'discover' => 'Discover',
    'other' => 'Other',
);

// Payment plan terms
$app_list_strings['payment_term_list'] = array(
    '3' => '3 Months',
    '6' => '6 Months',
    '12' => '12 Months',
    '18' => '18 Months',
    '24' => '24 Months',
);
?>