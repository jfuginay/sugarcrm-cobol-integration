<?php
/**
 * Pre-uninstall script for Payment Bridge Module
 * Backs up data and checks dependencies before removal
 */

function pre_uninstall() {
    global $db, $sugar_config;
    
    // Check if there are any active payment plans
    $sql = "SELECT COUNT(*) as count FROM payment_plans WHERE deleted = 0 AND status IN ('active', 'pending')";
    $result = $db->query($sql);
    $row = $db->fetchByAssoc($result);
    
    if ($row['count'] > 0) {
        echo "\nWARNING: There are {$row['count']} active payment plans in the system.\n";
        echo "These will be affected if you uninstall the Payment Bridge module.\n";
        echo "Consider exporting this data before proceeding.\n\n";
    }
    
    // Check for recent transactions
    $sql = "SELECT COUNT(*) as count FROM payment_bridge WHERE deleted = 0 AND date_entered >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
    $result = $db->query($sql);
    $row = $db->fetchByAssoc($result);
    
    if ($row['count'] > 0) {
        echo "INFO: There are {$row['count']} payment transactions from the last 30 days.\n";
        echo "These records will be preserved in the database for audit purposes.\n\n";
    }
    
    // Create backup directory
    $backupDir = 'cache/PaymentBridge_backup_' . date('Y-m-d_H-i-s');
    if (!file_exists($backupDir)) {
        mkdir($backupDir, 0755, true);
    }
    
    // Export configuration
    $config_backup = array(
        'cobol_api_url' => $sugar_config['cobol_api_url'] ?? '',
        'cobol_api_timeout' => $sugar_config['cobol_api_timeout'] ?? 30,
        'cobol_api_retry_attempts' => $sugar_config['cobol_api_retry_attempts'] ?? 3,
        'payment_bridge_audit_enabled' => $sugar_config['payment_bridge_audit_enabled'] ?? true,
    );
    
    file_put_contents(
        $backupDir . '/config_backup.json',
        json_encode($config_backup, JSON_PRETTY_PRINT)
    );
    
    // Log uninstall attempt
    $GLOBALS['log']->info('PaymentBridge Module: Pre-uninstall backup completed. Backup location: ' . $backupDir);
    
    echo "Pre-uninstall checks completed.\n";
    echo "Configuration backed up to: $backupDir\n";
    echo "Proceeding with uninstall...\n";
}
?>