<?php
/**
 * Post-installation script for Payment Bridge Module
 * Creates database tables and configures the module
 */

function post_install() {
    global $sugar_config, $db;
    
    require_once('modules/Administration/QuickRepairAndRebuild.php');
    
    // Create database tables
    $sql_statements = array(
        // Payment Bridge main table
        "CREATE TABLE IF NOT EXISTS payment_bridge (
            id char(36) NOT NULL,
            name varchar(255) DEFAULT NULL,
            date_entered datetime DEFAULT NULL,
            date_modified datetime DEFAULT NULL,
            modified_user_id char(36) DEFAULT NULL,
            created_by char(36) DEFAULT NULL,
            description text,
            deleted tinyint(1) DEFAULT '0',
            assigned_user_id char(36) DEFAULT NULL,
            card_number_masked varchar(20) DEFAULT NULL,
            card_type varchar(50) DEFAULT NULL,
            validation_status varchar(50) DEFAULT NULL,
            validation_response text,
            transaction_id varchar(100) DEFAULT NULL,
            amount decimal(26,6) DEFAULT NULL,
            currency_id char(36) DEFAULT NULL,
            payment_date datetime DEFAULT NULL,
            PRIMARY KEY (id),
            KEY idx_payment_bridge_name (name),
            KEY idx_payment_bridge_assigned (assigned_user_id),
            KEY idx_payment_bridge_transaction (transaction_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8",
        
        // Payment Bridge audit table
        "CREATE TABLE IF NOT EXISTS payment_bridge_audit (
            id char(36) NOT NULL,
            parent_id char(36) NOT NULL,
            date_created datetime DEFAULT NULL,
            created_by varchar(36) DEFAULT NULL,
            field_name varchar(100) DEFAULT NULL,
            data_type varchar(100) DEFAULT NULL,
            before_value_string varchar(255) DEFAULT NULL,
            after_value_string varchar(255) DEFAULT NULL,
            before_value_text text,
            after_value_text text,
            PRIMARY KEY (id),
            KEY idx_payment_bridge_audit_parent_id (parent_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8",
        
        // Payment plans table
        "CREATE TABLE IF NOT EXISTS payment_plans (
            id char(36) NOT NULL,
            name varchar(255) DEFAULT NULL,
            date_entered datetime DEFAULT NULL,
            date_modified datetime DEFAULT NULL,
            modified_user_id char(36) DEFAULT NULL,
            created_by char(36) DEFAULT NULL,
            description text,
            deleted tinyint(1) DEFAULT '0',
            assigned_user_id char(36) DEFAULT NULL,
            principal_amount decimal(26,6) DEFAULT NULL,
            apr decimal(5,2) DEFAULT NULL,
            term_months int(11) DEFAULT NULL,
            monthly_payment decimal(26,6) DEFAULT NULL,
            total_interest decimal(26,6) DEFAULT NULL,
            start_date date DEFAULT NULL,
            end_date date DEFAULT NULL,
            status varchar(50) DEFAULT NULL,
            account_id char(36) DEFAULT NULL,
            contact_id char(36) DEFAULT NULL,
            PRIMARY KEY (id),
            KEY idx_payment_plans_account (account_id),
            KEY idx_payment_plans_contact (contact_id),
            KEY idx_payment_plans_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8",
        
        // System health metrics table
        "CREATE TABLE IF NOT EXISTS cobol_system_health (
            id char(36) NOT NULL,
            date_created datetime DEFAULT NULL,
            endpoint varchar(255) DEFAULT NULL,
            response_time_ms int(11) DEFAULT NULL,
            status_code int(11) DEFAULT NULL,
            is_successful tinyint(1) DEFAULT NULL,
            error_message text,
            PRIMARY KEY (id),
            KEY idx_system_health_date (date_created),
            KEY idx_system_health_endpoint (endpoint)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8"
    );
    
    // Execute SQL statements
    foreach ($sql_statements as $sql) {
        $result = $db->query($sql, true);
        if (!$result) {
            $GLOBALS['log']->fatal('PaymentBridge Module: Failed to create table. SQL: ' . $sql);
        }
    }
    
    // Add default configuration if not exists
    if (!isset($sugar_config['cobol_api_url'])) {
        require_once('modules/Configurator/Configurator.php');
        $configurator = new Configurator();
        $configurator->loadConfig();
        $configurator->config['cobol_api_url'] = 'http://localhost:3000/api';
        $configurator->config['cobol_api_timeout'] = 30;
        $configurator->config['cobol_api_retry_attempts'] = 3;
        $configurator->config['payment_bridge_audit_enabled'] = true;
        $configurator->saveConfig();
    }
    
    // Run repair and rebuild
    $repair = new RepairAndClear();
    $repair->repairAndClearAll(array('clearAll'), array('PaymentBridge'), true, false);
    
    // Add module to displayed modules
    require_once('modules/MySettings/TabController.php');
    $controller = new TabController();
    $controller->set_system_tabs();
    
    // Log successful installation
    $GLOBALS['log']->info('PaymentBridge Module: Installation completed successfully');
    
    echo "Payment Bridge Module installed successfully!\n";
    echo "Database tables created.\n";
    echo "Module configured and ready to use.\n";
    echo "\nIMPORTANT: Configure your COBOL API endpoint in Admin > System Settings:\n";
    echo "- COBOL API URL: Set to your COBOL API endpoint\n";
    echo "- COBOL API Timeout: Adjust based on your system requirements\n";
}
?>