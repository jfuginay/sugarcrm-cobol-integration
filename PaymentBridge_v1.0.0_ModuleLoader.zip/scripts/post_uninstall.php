<?php
/**
 * Post-uninstall script for Payment Bridge Module
 * Cleans up after module removal
 */

function post_uninstall() {
    global $db;
    
    // Note: We do NOT drop the tables by default to preserve audit data
    // Uncomment the following lines if you want to completely remove all data
    
    /*
    $tables_to_drop = array(
        'payment_bridge',
        'payment_bridge_audit',
        'payment_plans',
        'cobol_system_health'
    );
    
    foreach ($tables_to_drop as $table) {
        $sql = "DROP TABLE IF EXISTS $table";
        $db->query($sql);
    }
    */
    
    // Remove module from displayed modules
    require_once('modules/MySettings/TabController.php');
    $controller = new TabController();
    $controller->set_system_tabs();
    
    // Clean up cache
    require_once('modules/Administration/QuickRepairAndRebuild.php');
    $repair = new RepairAndClear();
    $repair->clearVardefs();
    $repair->clearJsFiles();
    $repair->clearTpls();
    
    // Log successful uninstall
    $GLOBALS['log']->info('PaymentBridge Module: Uninstall completed successfully');
    
    echo "\nPayment Bridge Module uninstalled successfully.\n";
    echo "\nIMPORTANT NOTES:\n";
    echo "- Database tables have been PRESERVED for audit compliance\n";
    echo "- To completely remove all data, manually drop these tables:\n";
    echo "  - payment_bridge\n";
    echo "  - payment_bridge_audit\n";
    echo "  - payment_plans\n";
    echo "  - cobol_system_health\n";
    echo "\n- Configuration settings have been preserved\n";
    echo "- Check cache/PaymentBridge_backup_* for configuration backups\n";
}
?>