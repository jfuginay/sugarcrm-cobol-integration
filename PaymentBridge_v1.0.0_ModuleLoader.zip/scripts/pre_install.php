<?php
/**
 * Pre-installation script for Payment Bridge Module
 * Checks system requirements and prepares environment
 */

function pre_install() {
    global $sugar_config, $mod_strings;
    
    // Check PHP version
    if (version_compare(PHP_VERSION, '7.2.0', '<')) {
        die('Payment Bridge Module requires PHP 7.2 or higher. Current version: ' . PHP_VERSION);
    }
    
    // Check if cURL is enabled (required for API calls)
    if (!extension_loaded('curl')) {
        die('Payment Bridge Module requires the cURL PHP extension to be enabled.');
    }
    
    // Check if JSON extension is enabled
    if (!extension_loaded('json')) {
        die('Payment Bridge Module requires the JSON PHP extension to be enabled.');
    }
    
    // Check write permissions on custom directory
    $customDir = 'custom/modules';
    if (!is_writable($customDir)) {
        die("Payment Bridge Module requires write permissions on the '$customDir' directory.");
    }
    
    // Create module directories if they don't exist
    $moduleDir = 'custom/modules/PaymentBridge';
    if (!file_exists($moduleDir)) {
        if (!mkdir($moduleDir, 0755, true)) {
            die("Unable to create directory: $moduleDir");
        }
    }
    
    // Log installation attempt
    $GLOBALS['log']->info('PaymentBridge Module: Pre-installation checks completed successfully');
    
    echo "Pre-installation checks completed successfully.\n";
    echo "Payment Bridge Module is ready to install.\n";
}
?>