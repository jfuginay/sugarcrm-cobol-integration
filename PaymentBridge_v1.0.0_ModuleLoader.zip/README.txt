COBOL Payment Bridge Module for SuiteCRM
========================================

Version: 1.0.0
Author: Enterprise Integration Team
License: AGPLv3

OVERVIEW
--------
The COBOL Payment Bridge module enables SuiteCRM to integrate with legacy COBOL payment 
systems, providing modern payment processing capabilities while preserving existing 
COBOL infrastructure. This is ideal for insurance and financial services companies 
that need to modernize their CRM without replacing proven legacy systems.

FEATURES
--------
1. Payment Gateway Integration
   - Real-time credit card validation
   - PCI-compliant card masking
   - Transaction processing

2. Interest Calculator
   - Dynamic APR calculations
   - Multiple payment plan options
   - Amortization schedules

3. Statement Generation
   - JSON and PDF formats
   - Custom templates
   - Automated delivery

4. Credit Limit Management
   - Real-time limit tracking
   - Visual dashboards
   - Automated alerts

5. Payment Plan Management
   - Flexible plan creation
   - Automated scheduling
   - Payment tracking

6. System Health Monitoring
   - COBOL system metrics
   - Performance tracking
   - Availability monitoring

REQUIREMENTS
------------
- SuiteCRM 7.x or 8.x
- PHP 7.2 or higher
- MySQL 5.7 or higher
- cURL PHP extension
- JSON PHP extension
- COBOL API endpoint (separate installation)

INSTALLATION
------------
1. Log in to SuiteCRM as Administrator
2. Navigate to Admin > Module Loader
3. Click "Choose File" and select this module package
4. Click "Upload" and then "Install"
5. Follow the installation wizard
6. After installation, configure the module:
   - Go to Admin > System Settings
   - Set "COBOL API URL" to your COBOL API endpoint
   - Adjust timeout and retry settings as needed

CONFIGURATION
-------------
Add to config_override.php:

$sugar_config['cobol_api_url'] = 'http://your-cobol-api:3000/api';
$sugar_config['cobol_api_timeout'] = 30;
$sugar_config['cobol_api_retry_attempts'] = 3;
$sugar_config['payment_bridge_audit_enabled'] = true;

USAGE
-----
After installation, access the Payment Bridge module from the main menu:
- Payment Bridge > Validate Card
- Payment Bridge > Interest Calculator
- Payment Bridge > Generate Statement
- Payment Bridge > Credit Limit Dashboard
- Payment Bridge > Payment Plan Manager
- Payment Bridge > System Health Monitor

SECURITY
--------
- All card numbers are masked (showing only first 4 and last 4 digits)
- Full card numbers are never stored in the database
- All transactions are logged for audit compliance
- API communications use secure protocols

TROUBLESHOOTING
---------------
1. Module not appearing in menu:
   - Run Quick Repair and Rebuild
   - Check module permissions in Role Management

2. API connection errors:
   - Verify COBOL API URL in configuration
   - Check firewall settings
   - Ensure COBOL API service is running

3. Database errors:
   - Check MySQL permissions
   - Run database repair from Admin panel

UNINSTALLATION
--------------
1. Navigate to Admin > Module Loader
2. Find "COBOL Payment Bridge" in installed modules
3. Click "Uninstall"
4. Note: Database tables are preserved for audit compliance
5. To completely remove data, manually drop the following tables:
   - payment_bridge
   - payment_bridge_audit
   - payment_plans
   - cobol_system_health

SUPPORT
-------
- Documentation: https://github.com/jfuginay/sugarcrm-cobol-integration
- Issues: https://github.com/jfuginay/sugarcrm-cobol-integration/issues
- COBOL API: https://github.com/jfuginay/cobol-credit-api

CHANGELOG
---------
Version 1.0.0 (2025-01-21)
- Initial release
- Full feature set implementation
- Production-ready architecture
- Comprehensive audit logging

COPYRIGHT
---------
Copyright (C) 2025 Enterprise Integration Team
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.